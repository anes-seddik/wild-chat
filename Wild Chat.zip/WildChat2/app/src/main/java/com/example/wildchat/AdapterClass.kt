package com.example.wildchat


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.receive_message_layout.view.*
import kotlinx.android.synthetic.main.receive_picture_layout.view.*
import kotlinx.android.synthetic.main.send_message_layout.view.*
import kotlinx.android.synthetic.main.send_picture_layout.view.*
import kotlinx.android.synthetic.main.send_picture_layout.view.picture_send


class AdapterClass (var items : ArrayList<textModel> = arrayListOf<textModel>(),
                    var userId: String = "") : RecyclerView.Adapter<RecyclerView.ViewHolder>(){



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == R.layout.send_message_layout){
            return MyViewHolder(
                LayoutInflater.from(parent.context).inflate(
                    R.layout.send_message_layout,parent,false

                )
            )
        }
        else if (viewType == R.layout.receive_message_layout)   {
            return TheirViewHolder(
                LayoutInflater.from(parent.context).inflate(
                    R.layout.receive_message_layout,parent,false

                )
            )
        }
        else if (viewType == R.layout.send_picture_layout) return MyPicViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.send_picture_layout,parent,false

            )
        )
        else return TheirPicViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.receive_picture_layout,parent,false

            )
        )

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {


        when(holder){
            is MyViewHolder -> holder.bind(items[position])
            is TheirViewHolder -> holder.bind(items[position])
            is MyPicViewHolder -> holder.bind(items[position])
            is TheirPicViewHolder -> holder.bind(items[position])
        }


    }

    override fun getItemCount(): Int {
        return items.size
    }

    class MyViewHolder(Itemview: View) : RecyclerView.ViewHolder(Itemview) {

        private val msg_content = Itemview.msg_content
        fun bind (message: textModel){
            msg_content.text = message.text
        }

    }
    class TheirViewHolder(Itemview: View) : RecyclerView.ViewHolder(Itemview) {

        private val sender_name = Itemview.others_sender_name
        private val msg_content = Itemview.others_msg_content
        fun bind (message: textModel){
            sender_name.text = message.name
            msg_content.text = message.text
        }

    }
    class MyPicViewHolder(Itemview: View) : RecyclerView.ViewHolder(Itemview) {

        private val img = Itemview.picture_send
        fun bind (message: textModel){
            Picasso.get().load(message.imgUrl).into(img)
        }

    }
    class TheirPicViewHolder(Itemview: View) : RecyclerView.ViewHolder(Itemview) {

        private val sender_name = Itemview.img_sender_name
        private val img = Itemview.picture_receive
        fun bind (message: textModel){
            sender_name.text = message.name
            Picasso.get().load(message.imgUrl).into(img)
        }

    }

    override fun getItemViewType(position: Int): Int {
        return if (!items[position].imgUrl.isNullOrEmpty()){
            if (items[position].UID.toString() == userId ){
                R.layout.send_picture_layout
            }
            else R.layout.receive_picture_layout

        }
        else if (items[position].UID.toString() == userId ){
            R.layout.send_message_layout
        }else{
            R.layout.receive_message_layout
        }


    }
    fun addmsg (msgList : ArrayList<textModel>){
        items = msgList
        notifyItemInserted(itemCount)
    }

}