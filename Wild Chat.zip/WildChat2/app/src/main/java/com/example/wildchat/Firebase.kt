package com.example.wildchat

import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference


class FirebaseClass {

    var firebaseAuth2 : FirebaseAuth
    var profilePics_storageRef2 : StorageReference
    var sentPics_storageRef2 : StorageReference
    var textsDbRef2 : DatabaseReference
    var usersDbRef2 : DatabaseReference
    var userId : String?


    init {
        firebaseAuth2 = FirebaseAuth.getInstance()
        profilePics_storageRef2 = FirebaseStorage.getInstance().getReference("profile_pics")
        sentPics_storageRef2 = FirebaseStorage.getInstance().getReference("sent_pics")

        textsDbRef2 = FirebaseDatabase.getInstance().getReference("texts")
        usersDbRef2 = FirebaseDatabase.getInstance().getReference("users")
        userId = firebaseAuth2.currentUser?.uid
    }






}