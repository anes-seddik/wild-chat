package com.example.wildchat

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.wildchat.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.login_dialog.*
import kotlinx.android.synthetic.main.register_dialog.*

class MainActivity : AppCompatActivity() {


    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var mSdialog : Dialog
    private lateinit var mRdialog : Dialog
    lateinit var dbRef : DatabaseReference


    private lateinit var sharedPrefs : SharedPreferences
    private var logedIn =false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sharedPrefs = getSharedPreferences("sp", Context.MODE_PRIVATE)
        dbRef = Firebase.database.getReference("users")

        logedIn = sharedPrefs.getBoolean("loged",false)
        firebaseAuth = FirebaseAuth.getInstance()

        if (logedIn){
            val intent = Intent(this,main_chat::class.java)
            startActivity(intent)
            finish()
            Toast.makeText(this, "Loged in successfully !", Toast.LENGTH_SHORT).show()

        }
        else{
            showSignin()

        }
    }

    private fun showSignin() {
        val  mDialogView = LayoutInflater.from(this).inflate(R.layout.login_dialog,null)
        val mBuilder = AlertDialog.Builder(this)
        mBuilder.setView(mDialogView)
        mSdialog = mBuilder.create()

        mSdialog.show()
        mSdialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        mSdialog.setCancelable(false)
        val register = mSdialog.registerTXT
        val signin = mSdialog.login_btn


        signin.setOnClickListener {
            signInFirebase()

        }

        register.setOnClickListener {
            mSdialog.dismiss()
            showRegister()
        }

    }



    private fun showRegister() {
        val  mDialogView = LayoutInflater.from(this).inflate(R.layout.register_dialog,null)
        val mBuilder = AlertDialog.Builder(this)
        mBuilder.setView(mDialogView)
        mRdialog = mBuilder.create()


        mRdialog.show()
        mRdialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        mRdialog.setCancelable(false)
        val signin = mRdialog.loginTXT
        val signup = mRdialog.register_btn


        signup.setOnClickListener {

            registerFirebase()

        }
        signin.setOnClickListener {
            mRdialog.dismiss()
            showSignin()
        }


    }

    private fun registerFirebase() {
        val name = mRdialog.name1.text.toString()
        val email = mRdialog.email1.text.toString()
        val pass1 = mRdialog.password1.text.toString()
        val pass2 = mRdialog.password_confirm1.text.toString()
        if (email.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches() && name.isNotEmpty() && pass1.isNotEmpty() && pass2.isNotEmpty()){
            if (pass1== pass2){

                val currentUser = userModel(name,email,pass1)

                firebaseAuth.createUserWithEmailAndPassword(email,pass1).addOnCompleteListener {
                    if (it.isSuccessful){

                        dbRef.child(FirebaseAuth.getInstance().currentUser!!.uid).setValue(currentUser).addOnCompleteListener {
                            if (it.isSuccessful){
                                mRdialog.dismiss()

                                showSignin()
                                Toast.makeText(this, "Registered successfully !", Toast.LENGTH_SHORT).show()

                            }
                            else {
                                Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                            }
                        }

                    }
                    else {
                        Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                    }
                }



            }
            else { Toast.makeText(this, "password not matching", Toast.LENGTH_SHORT).show() }
        }else
            Toast.makeText(this, "email or pass are empty", Toast.LENGTH_SHORT).show()
    }

    private fun signInFirebase() {
        val email = mSdialog.login_email.text.toString()
        val pass = mSdialog.login_password.text.toString()
        if (email.isNotEmpty() && pass.isNotEmpty() ){


            firebaseAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener {
                if (it.isSuccessful){
                    mSdialog.dismiss()
                    val intent = Intent(this,main_chat::class.java)

                    startActivity(intent)
                    finish()
                    Toast.makeText(this, "Loged in successfully !", Toast.LENGTH_SHORT).show()
                    logedIn = true
                    val editor = sharedPrefs.edit()
                    editor.putBoolean("loged",logedIn)

                    editor.apply()

                }
                else {
                    Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                }
            }


        }else
            Toast.makeText(this, "email or pass are empty", Toast.LENGTH_SHORT).show()

    }




}