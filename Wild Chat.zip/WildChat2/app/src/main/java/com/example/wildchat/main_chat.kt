package com.example.wildchat


import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main_chat.*
import kotlinx.android.synthetic.main.register_dialog.*

class main_chat : AppCompatActivity() {

    lateinit var dbRef : DatabaseReference
    lateinit var usersDbRef : DatabaseReference
    private lateinit var firebaseAuth: FirebaseAuth
    private var NAME = ""
    private lateinit var sharedPrefs : SharedPreferences

    private var msgList = arrayListOf<textModel>()
    lateinit var Adapter : AdapterClass
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_chat)


        val layoutManager = LinearLayoutManager(this)
        layoutManager.stackFromEnd = true
        recyclerView_messages.layoutManager = layoutManager

        firebaseAuth = FirebaseAuth.getInstance()
        sharedPrefs = getSharedPreferences("sp", Context.MODE_PRIVATE)
        dbRef = Firebase.database.reference.child("texts")



        NAME = sharedPrefs.getString("username","").toString()
        if (NAME.trim().isNotEmpty()){
            username.text = NAME
        }
        else{
            usersDbRef = Firebase.database.reference.child("users")
            usersDbRef.child(firebaseAuth.currentUser!!.uid).addValueEventListener(
                object : ValueEventListener {
                    override fun onCancelled(p0: DatabaseError) {
                    }

                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {

                            NAME = p0.child("name").value.toString()
                            username.text = NAME
                            val editor = sharedPrefs.edit()
                            editor.putString("username",NAME)
                            editor.apply()

                        }
                        else Toast.makeText(this@main_chat, "user doesn't exist", Toast.LENGTH_LONG).show()
                    }

                })


        }



        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {
            }

            override fun onDataChange(p0: DataSnapshot) {
                if (p0.exists()) {
                    msgList.clear()
                    for (message in p0.children){
                        val msg = message.getValue(textModel::class.java)

                        msgList.add(msg!!)

                    }

                    recyclerView_messages.scrollToPosition((msgList.size)-1)




                }
                else Toast.makeText(this@main_chat, "this chat is empty !", Toast.LENGTH_LONG).show()
            }

        })

        Adapter = AdapterClass(msgList,NAME)

        recyclerView_messages.adapter = Adapter








        textfield.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (textfield.text.toString().equals("")){
                    gallery.visibility = View.VISIBLE
                    send.visibility = View.GONE

                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (textfield.text.toString() != ""){
                    gallery.visibility = View.GONE
                    send.visibility = View.VISIBLE
                }
            }
        })
    }


    fun sendToDb(view: View) {

        //getting data


        val message = textfield.text.toString()



        val userId =dbRef.push().key!!
        if (message.trim() != ""){

            val messageInfo = textModel(NAME,message)

            // inserting to DB

            dbRef.child(userId).setValue(messageInfo).addOnCompleteListener {
                if (it.isSuccessful){

                    Toast.makeText(this, "data submited successfully !", Toast.LENGTH_SHORT).show()
                    textfield.setText("")
                    textfield.hideKeyboard()

                }

                else {
                    Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun View.hideKeyboard() {
        val inputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(windowToken, 0)
    }

    fun logout(view: View) {
        firebaseAuth.signOut()
        val editor = sharedPrefs.edit()
        editor.putBoolean("loged",false)
        editor.putString("username","")
        editor.apply()
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        Toast.makeText(this, "Loged out successfully", Toast.LENGTH_SHORT).show()

    }

}