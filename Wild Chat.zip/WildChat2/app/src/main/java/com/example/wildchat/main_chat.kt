package com.example.wildchat


import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main_chat.*
import kotlinx.android.synthetic.main.activity_user_profile.*
import kotlinx.android.synthetic.main.register_dialog.*
import kotlinx.android.synthetic.main.send_image_dialog.*

class main_chat : AppCompatActivity() {


    private var NAME = ""
    private lateinit var sharedPrefs : SharedPreferences
    private var msgList = arrayListOf<textModel>()
    lateinit var Adapter : AdapterClass
    private var imageUri: Uri? = null
    private var picture_uri: Uri? = null

    private lateinit var firebaseAuth : FirebaseAuth
    private lateinit var profilePics_storageRef : StorageReference
    private lateinit var sentPics_storageRef : StorageReference
    private lateinit var textsDbRef : DatabaseReference
    private lateinit var usersDbRef : DatabaseReference
    private lateinit var userId : String
    private lateinit var sendImg_dialog : Dialog




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_chat)

        FirebaseClass()

        //// INITIALIZE FIREBASE ////
        firebaseAuth = FirebaseClass().firebaseAuth2
        profilePics_storageRef = FirebaseClass().profilePics_storageRef2
        sentPics_storageRef= FirebaseClass().sentPics_storageRef2
        textsDbRef = FirebaseClass().textsDbRef2
        usersDbRef = FirebaseClass().usersDbRef2

        userId  = FirebaseClass().userId!!

       //// INITIALIZE SHARED PREFS ////
        sharedPrefs = getSharedPreferences("sp", Context.MODE_PRIVATE)

        /// LAYOUT MANAGER ///
        val layoutManager = LinearLayoutManager(this)
        layoutManager.stackFromEnd = true
        recyclerView_messages.layoutManager = layoutManager

        ///// DISPLAY USERNAME ////

        NAME = sharedPrefs.getString("username","").toString()
        displayName()



        ///// DISPLAY PICTURE ////
        displayProfilePic()


        ///// GETTING TEXTS FROM DB ////
        textsDbRef.addValueEventListener(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {
            }

            override fun onDataChange(p0: DataSnapshot) {
                if (p0.exists()) {
                    msgList.clear()
                    for (message in p0.children){
                        val msg = message.getValue(textModel::class.java)

                        msgList.add(msg!!)

                    }

                    recyclerView_messages.scrollToPosition((msgList.size)-1)




                }
                else Toast.makeText(this@main_chat, "this chat is empty !", Toast.LENGTH_LONG).show()
            }

        })

        Adapter = AdapterClass(msgList,userId)

        recyclerView_messages.adapter = Adapter





        //// text listener to change icons when writing ////

        textfield.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (textfield.text.toString().equals("")){
                    gallery.visibility = View.VISIBLE
                    send.visibility = View.GONE

                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (textfield.text.toString() != ""){
                    gallery.visibility = View.GONE
                    send.visibility = View.VISIBLE
                }
            }
        })
        avatar.setOnClickListener {
            val intent = Intent(this, User_Profile::class.java)

            startActivity(intent) }
    }

    private fun displayProfilePic() {
        if (sharedPrefs.contains("profile_pic")){
            imageUri = Uri.parse(sharedPrefs.getString("profile_pic",""))
            Glide.with(this@main_chat).load(imageUri).into(avatar)


        }
        ///////////// ADD ELSE STATEMENT /////////////
        else {
            usersDbRef.child(userId).child("imgUrl").addValueEventListener(
                object : ValueEventListener {
                    override fun onCancelled(p0: DatabaseError) {
                    }

                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {
                            val imgURL = p0.value.toString()
                            if (imgURL.isNotEmpty()){
                                imageUri = Uri.parse(imgURL)
                                val editor = sharedPrefs.edit()
                                editor.putString("profile_pic", imageUri.toString())
                                editor.apply()
                                Glide.with(this@main_chat).load(imageUri).into(avatar)

                            }
                        }
                        else Toast.makeText(this@main_chat, "user doesn't exist", Toast.LENGTH_LONG).show()
                    }

                })
        }
    }

    private fun displayName() {
        if (NAME.trim().isNotEmpty()){
            username.text = NAME
        }
        else{

            usersDbRef.child(userId).addValueEventListener(
                object : ValueEventListener {
                    override fun onCancelled(p0: DatabaseError) {
                    }

                    override fun onDataChange(p0: DataSnapshot) {
                        if (p0.exists()) {

                            NAME = p0.child("name").value.toString()
                            username.text = NAME
                            val editor = sharedPrefs.edit()
                            editor.putString("username",NAME)
                            editor.apply()

                        }
                    }

                })


        }
    }


    fun sendToDb(view: View) {

        //getting data


        val message = textfield.text.toString()



        if (message.trim() != ""){

            val messageInfo = textModel(NAME,message.trim(),userId)

            // inserting to DB
            val textId =textsDbRef.push().key!!

            textsDbRef.child(textId).setValue(messageInfo).addOnCompleteListener {
                if (it.isSuccessful){


                    textfield.setText("")
                    textfield.hideKeyboard()
                    Toast.makeText(this, "data submited successfully !", Toast.LENGTH_SHORT).show()

                }

                else {
                    Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun View.hideKeyboard() {
        val inputMethodManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(windowToken, 0)
    }

    fun toastURI(view: View) {
        Toast.makeText(this, "uri = $imageUri", Toast.LENGTH_LONG).show()
    }

    fun get_pic(view: View) {
        val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
        startActivityForResult(gallery, 100)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == 100 && data != null) {

            picture_uri = data.data

            /////  initializilng dialog to show selected img /////

            val  mDialogView = LayoutInflater.from(this).inflate(R.layout.send_image_dialog,null)
            val mBuilder = AlertDialog.Builder(this)
            mBuilder.setView(mDialogView)
            sendImg_dialog= mBuilder.create()
            sendImg_dialog.show()
            sendImg_dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)


            Glide.with(this).load(picture_uri).into(sendImg_dialog.picture_show)

            sendImg_dialog.save_btn_dialog.setOnClickListener {
                sendImageToDb()


            }

        }
        else Toast.makeText(this, "Couldn't upload this image !", Toast.LENGTH_SHORT).show()
    }

    private fun sendImageToDb() {
        val textId =textsDbRef.push().key!!

        sentPics_storageRef.child(textId).putFile(picture_uri!!).addOnSuccessListener {
            sentPics_storageRef.child(textId).downloadUrl.addOnSuccessListener {
                val URL = it
                textsDbRef.child(textId).setValue(textModel(name = NAME, UID = userId, imgUrl = URL.toString())).addOnSuccessListener { sendImg_dialog.dismiss()
                    Toast.makeText(this, "image stored !", Toast.LENGTH_SHORT).show()}.addOnFailureListener { sendImg_dialog.dismiss()
                    Toast.makeText(this, "failed to store this image !", Toast.LENGTH_SHORT).show() }
            }.addOnFailureListener { sendImg_dialog.dismiss()
                Toast.makeText(this, "download URL failed", Toast.LENGTH_SHORT).show() }
        }.addOnFailureListener {sendImg_dialog.dismiss()
            Toast.makeText(this, "uploading to storage failed", Toast.LENGTH_SHORT).show() }


    }


}