package com.example.wildchat

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main_chat.*
import kotlinx.android.synthetic.main.activity_user_profile.*



private lateinit var sharedPrefs : SharedPreferences
private var imageUri: Uri? = null

private lateinit var firebaseAuth: FirebaseAuth
private lateinit var storageRef : StorageReference
private lateinit var usersDbRef : DatabaseReference
private lateinit var userId : String

class User_Profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)

        //// INITIALIZE FIREBASE REFS ////
        usersDbRef = FirebaseClass().usersDbRef2
        storageRef = FirebaseClass().profilePics_storageRef2
        firebaseAuth = FirebaseClass().firebaseAuth2
        userId = FirebaseClass().userId!!
        //// Shared prefs ////
        sharedPrefs = getSharedPreferences("sp", Context.MODE_PRIVATE)

        if (sharedPrefs.contains("profile_pic")){
            imageUri = Uri.parse(sharedPrefs.getString("profile_pic",null))
            Glide.with(this).load(imageUri).into(user_pic)
        }


    }

    fun logout(view: View) {
        firebaseAuth.signOut()
        val editor = sharedPrefs.edit()
        editor.putBoolean("loged",false)
        editor.putString("username","")
        editor.putString("profile_pic", null)
        editor.apply()
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        Toast.makeText(this, "Loged out successfully", Toast.LENGTH_SHORT).show()
    }

    fun get_pic(view: View) {
        val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
        startActivityForResult(gallery, 100)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == 100 && data != null) {

            imageUri = data.data
            Glide.with(this).load(imageUri).into(user_pic)

        }
        else Toast.makeText(this, "Couldn't upload this image !", Toast.LENGTH_SHORT).show()
    }



    fun store_changes(view: View) {

        // showing a progress dialog
        val progressDialog =  ProgressDialog(this)
        progressDialog.setMessage("Updating...")
        progressDialog.setCancelable(false)
        progressDialog.show()

        ///// cheking if the user didn't update the current image ////
        if (imageUri.toString() == sharedPrefs.getString("profile_pic",null).toString()){
            val intent = Intent(this, main_chat::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            Toast.makeText(this, "Image updated successfully !", Toast.LENGTH_SHORT).show()
        }
        else{
            // uploading the image the firebase storage
            storageRef.child(userId).putFile(imageUri!!).addOnSuccessListener {
                val editor = sharedPrefs.edit()
                storageRef.child(userId).downloadUrl.addOnSuccessListener { val URL  = it

                    /// Update Realtime database with image URL////

                    usersDbRef.child(userId).child("imgUrl").setValue(URL.toString()).addOnSuccessListener {

                        if (progressDialog.isShowing) progressDialog.dismiss()


                        // saving image to shared prefs

                        editor.putString("profile_pic", imageUri.toString())
                        editor.apply()


                        val intent = Intent(this, main_chat::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)


                        Toast.makeText(this, "Image updated successfully !", Toast.LENGTH_SHORT).show()
                    }.addOnFailureListener { if (progressDialog.isShowing) progressDialog.dismiss()
                        Toast.makeText(this, "updating DATABASE FAILED !", Toast.LENGTH_SHORT).show()
                    }

                }.addOnFailureListener { Toast.makeText(this, "download URL failed !!!", Toast.LENGTH_SHORT).show() }

            }.addOnFailureListener {
                if (progressDialog.isShowing) progressDialog.dismiss()
                Toast.makeText(this, it.toString(), Toast.LENGTH_SHORT).show() }
        }





    }


}