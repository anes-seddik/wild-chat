package com.example.wildchat

data class userModel(
    var name : String? = null,
    var email : String? = null,
    var pass : String? = null

)
