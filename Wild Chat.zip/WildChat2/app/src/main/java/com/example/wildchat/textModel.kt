package com.example.wildchat

data class textModel(
    var name : String? = "",
    var text : String? = ""


)
