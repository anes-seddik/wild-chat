package com.example.wildchat

data class textModel(
    var name : String? = "",
    var text : String? = "",
    var UID : String? = null,
    var imgUrl : String? = null


)
