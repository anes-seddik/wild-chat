package com.shopping.e_commerce.pojo

class items(var image:String, var name:String,var price:String) {
    constructor() : this("","",""){}
}