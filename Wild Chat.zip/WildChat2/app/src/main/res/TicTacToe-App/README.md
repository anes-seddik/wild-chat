![](https://img.shields.io/badge/Application-Tic_Tac_Toe-yellow.svg)
![](https://img.shields.io/badge/Programming_Language-Kotlin-blue.svg)
![](https://img.shields.io/badge/Kotlin_Version-211.1.6.10-skyblue.svg)
![](https://img.shields.io/badge/Android_Studio_Version-Bumblebee_2021.1.1-skyblue.svg)
![](https://img.shields.io/badge/Level-Basic-red.svg)
![](https://img.shields.io/badge/Status-Complete-green.svg)

<h1 align="center">Tic Tac Toe Game App</h1>

<p align="center">
<img src="https://i.postimg.cc/28H0BG3g/1.jpg" width=250 /> 
<img src="https://i.postimg.cc/t4Y2d6xJ/2.jpg" width=250 />
<img src="https://i.postimg.cc/wTxWvZxh/3.jpg" width=250 />
</p>

<h3 align="center"> Tic-Tac-Toe game app made with Kotlin <img src="https://www.vectorlogo.zone/logos/kotlinlang/kotlinlang-icon.svg" alt="kotlin" width="20" height="20"/> </a></h3>

<!-- ### [<p align="center">🔗 Demo video </p>](#) -->

<h3 align="center"> Show ❤️ by Starring this Repo </h3>
