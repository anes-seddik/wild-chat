# E-commerceShopAppUI-Android
New style for app design E-commerce Shop App UI made in Jetpack Compose.😉😎

(Navigation Components,
Dagger-Hilt,
Material Components)

# Screenshot

![68747470733a2f2f63646e2e6472696262626c652e636f6d2f75736572732f323433323939342f73637265656e73686f74732f31303434363132372f6d656469612f666130613963653334386530626661313862303062](https://user-images.githubusercontent.com/25154589/131151663-fee5f270-ee92-4f7a-adf2-62aaedd96064.png)


►Design Credit: https://dribbble.com/shots/10446127-E-commerce-App-Exploration/attachments/2283107?mode=media
