package com.arvind.nikeshop.utils

object Constants {
    const val SPLASH_SCREEN_DURATION = 0L
}